package com.example.app05_basedatos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
